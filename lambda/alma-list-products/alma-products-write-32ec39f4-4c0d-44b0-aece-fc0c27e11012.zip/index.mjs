import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand, UpdateCommand, DeleteCommand } from "@aws-sdk/lib-dynamodb";
import { randomUUID } from "crypto";

const client = new DynamoDBClient({});
const db = DynamoDBDocumentClient.from(client);
const TABLE = "Products";

export const handler = async (event) => {
  const method = event.requestContext.http.method;
  const body = event.body ? JSON.parse(event.body) : {};

  try {
    if (method === "POST") {
      const item = {
        id: randomUUID(),
        name: body.name,
        description: body.description,
        price: Number(body.price),
        category: body.category,
        image: body.image || ""
      };
      await db.send(new PutCommand({ TableName: TABLE, Item: item }));
      return response(201, item);
    }

    if (method === "PUT") {
      await db.send(new UpdateCommand({
        TableName: TABLE,
        Key: { id: body.id },
        UpdateExpression: "set #n=:n, description=:d, price=:p, category=:c, image=:i",
        ExpressionAttributeNames: { "#n": "name" },
        ExpressionAttributeValues: {
          ":n": body.name,
          ":d": body.description,
          ":p": Number(body.price),
          ":c": body.category,
          ":i": body.image || ""
        }
      }));
      return response(200, { message: "Updated" });
    }

    if (method === "DELETE") {
      await db.send(new DeleteCommand({ TableName: TABLE, Key: { id: body.id } }));
      return response(200, { message: "Deleted" });
    }

    return response(405, { message: "Method not allowed" });

  } catch (err) {
    return response(500, { message: err.message });
  }
};

const response = (statusCode, body) => ({
  statusCode,
  headers: { "Access-Control-Allow-Origin": "*", "Content-Type": "application/json" },
  body: JSON.stringify(body)
});