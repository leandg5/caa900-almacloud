import https from 'https';
import { DynamoDBClient, PutItemCommand } from '@aws-sdk/client-dynamodb';

const RESEND_API_KEY = process.env.RESEND_API_KEY;
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY;
const dynamo = new DynamoDBClient({ region: 'us-east-1' });

function formatPrice(p) {
  return parseFloat(p).toFixed(2);
}

async function stripeRequest(path, method, data) {
  const body = new URLSearchParams(data).toString();
  return new Promise((resolve, reject) => {
    const req = https.request({
      hostname: 'api.stripe.com',
      path,
      method,
      headers: {
        'Authorization': `Bearer ${STRIPE_SECRET_KEY}`,
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(body)
      }
    }, res => {
      let d = '';
      res.on('data', chunk => d += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(d) });
        } catch(e) {
          resolve({ status: res.statusCode, body: { raw: d } });
        }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

async function sendConfirmationEmail(toEmail, items, total, orderId) {
  const itemsHtml = items.map(item => `
    <tr><td style="padding:18px 0;border-bottom:1px solid #E8E0D5">
      <table width="100%" cellpadding="0" cellspacing="0"><tr>
        <td style="vertical-align:middle;padding-right:16px">
          <div style="font-family:Georgia,serif;font-size:15px;font-weight:700;color:#1A1A1A;margin-bottom:3px">${item.name}</div>
          <div style="font-family:Arial,sans-serif;font-size:11px;color:#888;letter-spacing:0.08em;text-transform:uppercase">Qty: ${item.quantity || 1}</div>
        </td>
        <td style="vertical-align:middle;text-align:right;white-space:nowrap">
          <span style="font-family:Georgia,serif;font-size:16px;font-weight:700;color:#B87333">$${formatPrice(item.price)}</span>
        </td>
      </tr></table>
    </td></tr>`).join('');

  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body style="margin:0;padding:0;background:#F2EDE6"><table width="100%" cellpadding="0" cellspacing="0" style="background:#F2EDE6;padding:40px 0"><tr><td align="center"><table width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;background:#FFFFFF;border-radius:4px;overflow:hidden"><tr><td style="background:#0F1B2E;padding:44px 48px 36px;text-align:center"><div style="width:48px;height:48px;background:#B87333;border-radius:50%;margin:0 auto 20px;line-height:48px;text-align:center"><span style="color:#FFFFFF;font-size:22px;font-weight:700">&#10003;</span></div><div style="font-family:Georgia,serif;font-size:28px;font-weight:700;color:#FFFFFF;margin-bottom:8px">Order Confirmed</div><div style="font-family:Arial,sans-serif;font-size:13px;color:#8A9BB0;letter-spacing:0.1em;text-transform:uppercase;margin-bottom:20px">Thank you for your purchase</div><div style="display:inline-block;background:rgba(184,115,51,0.15);border:1px solid #B87333;border-radius:3px;padding:8px 20px"><span style="font-family:monospace;font-size:12px;color:#B87333;letter-spacing:0.12em">${orderId}</span></div></td></tr><tr><td style="padding:40px 48px 0"><table width="100%" cellpadding="0" cellspacing="0">${itemsHtml}</table></td></tr><tr><td style="padding:24px 48px 40px"><table width="100%" cellpadding="0" cellspacing="0" style="background:#F7F3EE;border-radius:4px;border-left:3px solid #B87333"><tr><td style="padding:24px"><table width="100%" cellpadding="0" cellspacing="0"><tr><td style="font-family:Georgia,serif;font-size:16px;font-weight:700;color:#1A1A1A">Total</td><td style="font-family:Georgia,serif;font-size:22px;font-weight:700;color:#B87333;text-align:right">$${formatPrice(total)}</td></tr></table></td></tr></table></td></tr><tr><td style="padding:32px 48px;text-align:center;border-top:1px solid #E8E0D5"><div style="font-family:Arial,sans-serif;font-size:10px;color:#AAA;letter-spacing:0.1em;text-transform:uppercase">© 2026 Alma Cloud · Seneca Polytechnic CAA900</div></td></tr></table></td></tr></table></body></html>`;

  const body = JSON.stringify({
    from: 'onboarding@resend.dev',
    to: [toEmail],
    subject: 'ALMA — Your order is confirmed',
    html,
    text: `Thank you! Order ${orderId} confirmed. Total: $${formatPrice(total)}`
  });

  return new Promise((resolve, reject) => {
    const req = https.request({
      hostname: 'api.resend.com',
      path: '/emails',
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body)
      }
    }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve({ status: res.statusCode, body: data }));
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

export const handler = async (event) => {
  try {
    const { items, total, email, paymentMethodId } = JSON.parse(event.body || '{}');

    if (!paymentMethodId) {
      return {
        statusCode: 400,
        headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Payment method required' })
      };
    }

    // 1. Procesar pago con Stripe
    const amountCents = Math.round(parseFloat(total) * 100);

    const intentResult = await stripeRequest('/v1/payment_intents', 'POST', {
      amount: amountCents,
      currency: 'cad',
      payment_method: paymentMethodId,
      confirm: 'true',
      return_url: 'https://main.du10ga3tf9jzo.amplifyapp.com/confirmation.html'
    });

    console.log('Stripe response:', JSON.stringify(intentResult.body));

    if (intentResult.body.status !== 'succeeded') {
      return {
        statusCode: 402,
        headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Payment failed', stripe_status: intentResult.body.status })
      };
    }

    // 2. Solo guardar orden si el pago fue exitoso
    const orderId = 'ALMA-' + Date.now();
    const toEmail = email || 'leandrodg5@gmail.com';

    await dynamo.send(new PutItemCommand({
      TableName: 'Alma-orders',
      Item: {
        id: { S: orderId },
        email: { S: toEmail },
        items: { S: JSON.stringify(items) },
        total: { N: String(total) },
        stripePaymentId: { S: intentResult.body.id },
        createdAt: { S: new Date().toISOString() }
      }
    }));

    // 3. Mandar email de confirmación
    const emailResult = await sendConfirmationEmail(toEmail, items, total, orderId);
    console.log('Email result:', emailResult.status, emailResult.body);

    return {
      statusCode: 200,
      headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' },
      body: JSON.stringify({ success: true, orderId })
    };

  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: err.message })
    };
  }
};